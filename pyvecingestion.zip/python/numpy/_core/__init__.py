"""
This private module only contains stubs for interoperability with
NumPy 2.0 pickled arrays. It may not be used by the end user.
"""
